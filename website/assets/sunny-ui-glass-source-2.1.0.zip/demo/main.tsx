import { createRoot } from "react-dom/client";
import { useRef, useState } from "react";
import { AppearancePicker, useAppearanceTheme, configureAppearance, materials, accents, corners } from "../src";
import "./demo.css";
import { GlassShowcase } from "./GlassShowcase";
configureAppearance({ storagePrefix: "sunny-ui-demo" });
function Demo() {
 const [theme,setTheme] = useAppearanceTheme();
 const [menu,setMenu] = useState(false);
 const [tab,setTab] = useState("全部");
 const [notice,setNotice] = useState("原有设计与预设保留，新增 SunnyTV 液态玻璃组件。");
 const dialog = useRef<HTMLDialogElement>(null);
 return <div className={`app ${menu ? "menu-open" : ""}`}>
  <aside className="sidebar"><a className="brand" href="#overview"><span className="brand-mark">S</span><span className="brand-text"><strong>Sunny UI</strong><small>DESIGN SYSTEM · 2.1</small></span></a><nav className="nav"><span className="nav-label">设计语言</span>{["外观概览","表面与控件","使用说明"].map((label,i) => <a key={label} className={`nav-item ${i===0 ? "active" : ""}`} href={i===2 ? "#guide" : "#overview"} onClick={() => setMenu(false)}><span>0{i+1}</span><strong>{label}</strong></a>)}</nav><div className="sidebar-spacer" /><div className="side-note">明暗 × 质感 × 配色 × 圆角<br />唯一视觉基准：MediaIndex 新预览</div><span className="version">Sunny UI 2.1.0</span></aside>
  <div className="menu-backdrop" onClick={() => setMenu(false)} />
  <div className="workspace"><header className="topbar"><button className="icon-btn menu-btn" aria-label="菜单" aria-expanded={menu} onClick={() => setMenu(!menu)}>☰</button><span className="crumb">Sunny UI / <strong>外观概览</strong></span><div className="top-actions"><AppearancePicker theme={theme} onThemeChange={() => setTheme(theme === "light" ? "dark" : "light")} /></div></header>
   <main className="content" id="overview"><header className="page-head"><div><p className="eyebrow">MATERIAL & COLOR</p><h1>同一套结构，不同的质感。</h1><p className="sub">从连续浮雕到拉丝金属，让背景、面板和控件共同表达材质。</p></div></header>
    <GlassShowcase />
    <section className="stat-strip">{[[materials.length,"界面质感"],[accents.length,"配色方案"],[2,"明暗模式"],[corners.length,"圆角档位"]].map(([n,label]) => <article className="panel stat-tile" key={label}><span>{label}</span><b>{n}</b><small>自由组合 · 独立选择</small></article>)}</section>
    <div className="split"><section className="panel panel-pad"><header className="panel-head"><div><h2>表面与日常操作</h2><small>与设计稿一致的面板、嵌套卡片、表单和状态</small></div><span className="pill ok"><i />已就绪</span></header><div className="sunny-demo-entries">{["主色 · 操作与选中","辅色 · 环境与层次","点缀 · 细节与氛围"].map((label,i) => <article className="entry-card" key={label}><div className="entry-top"><span className="entry-ic" style={{color:`var(--accent${i ? `-${i+1}` : ""})`}}>◈</span><span className="pill info">0{i+1}</span></div><b>{label}</b><p>材质来自页面环境、边缘、纹理和光影的共同作用。</p></article>)}</div><p className="sunny-demo-notice" role="status">{notice}</p><div className="seg" aria-label="记录筛选">{["全部","已就绪","待处理"].map(value => <button key={value} aria-pressed={tab===value} onClick={() => setTab(value)}>{value}</button>)}</div><div className="tbl-wrap"><table className="tbl"><thead><tr><th>项目名称</th><th>状态</th></tr></thead><tbody>{[["材质与颜色预设整理","已就绪"],["一个较长的项目名称，用于检查手机上的换行与完整阅读","待处理"]].filter(([,state]) => tab === "全部" || tab === state).map(([name,state]) => <tr key={name}><td>{name}</td><td><span className={`pill ${state === "已就绪" ? "ok" : "warn"}`}>{state}</span></td></tr>)}</tbody></table></div><div className="page-actions sunny-demo-actions"><button className="btn primary" onClick={() => dialog.current?.showModal()}>确认操作</button><button className="btn ghost" onClick={() => setNotice("已刷新示例，当前筛选与外观保留。")}>刷新示例</button></div></section>
    <section className="panel panel-pad"><header className="panel-head"><div><h2>表单设置</h2><small>输入框使用材质的内凹阴影</small></div></header><label className="field">项目名称<input className="input" defaultValue="我的工作空间" /></label><label className="field">显示方式<select className="input" defaultValue="舒适"><option>舒适</option><option>紧凑</option></select></label><label className="field">保存路径<input className="input" defaultValue="/workspace/design-system" /></label><p className="hint">示例不连接任何业务服务。外观选择在当前浏览器记忆。</p><span className="pill warn"><i />待处理 1 项</span></section></div>
    <section className="panel panel-pad" id="guide"><header className="panel-head"><div><h2>以设计稿为准</h2><small>原始 CSS 完整提取，保留纹理、配色和形状</small></div></header><p>打开右上角外观，分别切换明暗、圆角、材质与配色；刷新后继续使用所选外观。</p></section>
   </main></div>
   <dialog className="task-dialog" ref={dialog} aria-labelledby="confirm-title"><header className="td-head"><div className="grow"><span>本地示例</span><h2 id="confirm-title">确认操作</h2></div><button className="pop-close" aria-label="关闭确认" onClick={() => dialog.current?.close()}>×</button></header><div className="td-body"><p>此操作仅更新演示提示。</p></div><footer className="td-foot"><button className="btn ghost" onClick={() => dialog.current?.close()}>取消</button><button className="btn primary" onClick={() => {setNotice("已完成本地示例确认。");dialog.current?.close();}}>确认</button></footer></dialog>
 </div>;
}
createRoot(document.getElementById("root")!).render(<Demo />);
