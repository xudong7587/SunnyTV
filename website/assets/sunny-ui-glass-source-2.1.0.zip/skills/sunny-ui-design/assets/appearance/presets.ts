// Generated from the approved MediaIndex preview. Do not hand-edit.
export const materials = [
  {
    "id": "soft",
    "name": "柔软浮雕",
    "sample": "background:linear-gradient(158deg,#f8f9fb,#edf0f4);border:1px solid rgba(26,42,68,.05);box-shadow:4px 4px 9px rgba(26,42,68,.16),-3px -3px 7px #fff",
    "note": "连续基底上的连续凸起，控件按下会凹"
  },
  {
    "id": "clear",
    "name": "清晰默认",
    "sample": "background:#fff;border:1px solid #e4e8ef;box-shadow:0 1px 2px rgba(16,26,42,.08)",
    "note": "中性实色、轻边线，内容优先"
  },
  {
    "id": "paper",
    "name": "纸页档案",
    "sample": "background:linear-gradient(110deg,rgba(139,116,82,.07),transparent 45%),#fffdf7;border:1px solid #e0d6c3;box-shadow:inset 0 0 0 2px #fffefb,0 2px 0 rgba(139,116,82,.18)",
    "note": "暖纸、纤维、内嵌压痕"
  },
  {
    "id": "linen",
    "name": "亚麻织纹",
    "sample": "background:repeating-linear-gradient(45deg,rgba(110,100,80,.13) 0 1px,transparent 1px 3px),repeating-linear-gradient(-45deg,rgba(110,100,80,.11) 0 1px,transparent 1px 3px),#f6f4ee;border:1px solid #d5d0c2",
    "note": "斜向织纹，哑光无釉"
  },
  {
    "id": "glass",
    "name": "iOS 玻璃",
    "sample": "background:linear-gradient(135deg,rgba(255,255,255,.92),rgba(214,228,246,.5));border:1px solid rgba(255,255,255,.95);box-shadow:inset 0 1px 0 #fff,0 4px 10px rgba(16,26,42,.14)",
    "note": "清透中心、亮边、悬浮投影"
  },
  {
    "id": "frosted",
    "name": "雾面玻璃",
    "sample": "background:rgba(255,255,255,.68);border:1px solid rgba(255,255,255,.95);box-shadow:inset 0 2px 0 #fff,inset 0 -3px 6px rgba(20,30,45,.16)",
    "note": "更雾更厚，整块贴在墙上"
  },
  {
    "id": "aurora",
    "name": "极光玻璃",
    "sample": "background:linear-gradient(120deg,rgba(255,255,255,.8),rgba(110,205,225,.55) 45%,rgba(200,150,240,.5));border:1px solid rgba(255,255,255,.8);box-shadow:0 3px 10px rgba(70,140,170,.2)",
    "note": "三色柔光在玻璃后流动"
  },
  {
    "id": "duotone",
    "name": "双色渐层",
    "sample": "background:linear-gradient(125deg,color-mix(in srgb,var(--accent) 58%,#fff),color-mix(in srgb,var(--accent-2) 58%,#fff));border:1px solid color-mix(in srgb,var(--accent) 22%,#fff)",
    "note": "实色方向渐变，与玻璃拉开"
  },
  {
    "id": "satin",
    "name": "缎光瓷面",
    "sample": "background:linear-gradient(155deg,#fff,#e6edf8 38%,#fff 56%,#f0eef9);border:1px solid #e3e8f0;box-shadow:inset 0 1px 1px #fff,0 3px 8px rgba(24,38,61,.1)",
    "note": "斜向釉光，细腻高光"
  },
  {
    "id": "outline",
    "name": "精致描边",
    "sample": "background:#fff;border:1px solid color-mix(in srgb,var(--accent) 48%,#fff);box-shadow:0 2px 0 color-mix(in srgb,var(--accent) 20%,transparent)",
    "note": "只有线和一点底部厚度"
  },
  {
    "id": "metal",
    "name": "拉丝金属",
    "sample": "background:linear-gradient(105deg,transparent 26%,rgba(255,255,255,.65) 44%,transparent 60%),repeating-linear-gradient(0deg,rgba(255,255,255,.9) 0 1px,rgba(120,134,152,.22) 1px 2px,transparent 2px 4px),linear-gradient(180deg,#eef3f7,#c9d2dc);border:1px solid #aeb9c7;box-shadow:inset 0 1px 0 #fff,inset 0 -2px 0 #9ca8b8",
    "note": "横向拉丝、硬高光、冷银"
  },
  {
    "id": "clay",
    "name": "陶土哑光",
    "sample": "background:radial-gradient(120% 100% at 20% 0%,#fbf2e7,#e8d5c3);border:1px solid rgba(160,130,100,.24);box-shadow:0 7px 14px rgba(120,86,58,.24),inset 0 2px 2px rgba(255,255,255,.8)",
    "note": "暖色、颗粒、影子里没有高光"
  },
  {
    "id": "marble",
    "name": "大理石",
    "sample": "background:conic-gradient(from 118deg at 26% 38%,rgba(150,162,180,.3),transparent 12%,rgba(190,198,210,.26) 26%,transparent 42%,rgba(140,152,170,.28) 58%,transparent 76%),linear-gradient(160deg,#fff,#ecf0f4);border:1px solid rgba(150,160,175,.32);box-shadow:inset 0 1px 0 #fff",
    "note": "石纹大理面配釉光"
  },
  {
    "id": "neon",
    "name": "霓虹暗夜",
    "sample": "background:linear-gradient(160deg,#1a2236,#0b0f17);border:1px solid color-mix(in srgb,var(--accent) 65%,transparent);box-shadow:0 0 10px color-mix(in srgb,var(--accent) 50%,transparent),inset 0 0 10px color-mix(in srgb,var(--accent) 30%,transparent)",
    "note": "深色面板、边缘发光"
  },
  {
    "id": "cutout",
    "name": "纸片拼贴",
    "sample": "background:#fff;border:1px solid color-mix(in srgb,var(--accent) 58%,#93a2b6);box-shadow:3px 3px 0 color-mix(in srgb,var(--accent) 34%,transparent)",
    "note": "硬投影和实边线，像贴上去"
  },
  {
    "id": "mesh",
    "name": "雾面色场",
    "sample": "background:radial-gradient(60% 80% at 18% 12%,color-mix(in srgb,var(--accent) 60%,#fff),transparent 72%),radial-gradient(65% 85% at 88% 82%,color-mix(in srgb,var(--accent-2) 60%,#fff),transparent 72%),#f7f8fb;border:1px solid transparent;box-shadow:0 4px 10px rgba(20,30,50,.1)",
    "note": "页面很彩色，卡片退成哑光面"
  }
] as const;
export const single = [
  {
    "id": "blue",
    "name": "晴蓝",
    "light": "#376bd8",
    "dark": "#9dbbff"
  },
  {
    "id": "celadon",
    "name": "青瓷",
    "light": "#2f7f76",
    "dark": "#8fd6c9"
  },
  {
    "id": "green",
    "name": "松绿",
    "light": "#188466",
    "dark": "#7fd3b0"
  },
  {
    "id": "violet",
    "name": "鸢紫",
    "light": "#8855cc",
    "dark": "#c0a4f5"
  },
  {
    "id": "rose",
    "name": "莓红",
    "light": "#c34278",
    "dark": "#f0a3bf"
  },
  {
    "id": "brick",
    "name": "砖窑",
    "light": "#a8433a",
    "dark": "#eda79e"
  },
  {
    "id": "amber",
    "name": "琥珀",
    "light": "#b27a16",
    "dark": "#ebc078"
  },
  {
    "id": "mustard",
    "name": "芥末",
    "light": "#8f7a12",
    "dark": "#ddc66a"
  },
  {
    "id": "indigo",
    "name": "靛蓝",
    "light": "#3b4fa8",
    "dark": "#a9b6f0"
  },
  {
    "id": "slate",
    "name": "石墨",
    "light": "#61758f",
    "dark": "#b2c1d4"
  }
] as const;
export const multi = [
  {
    "id": "catppuccin",
    "name": "奶霜花园",
    "light": [
      "#c14f7c",
      "#179299",
      "#d20f39"
    ],
    "dark": [
      "#f0acc7",
      "#94e2d5",
      "#f5c2e7"
    ]
  },
  {
    "id": "nord",
    "name": "北境极光",
    "light": [
      "#427fa4",
      "#5e678d",
      "#42776c"
    ],
    "dark": [
      "#88c0d0",
      "#b48ead",
      "#a3be8c"
    ]
  },
  {
    "id": "iris",
    "name": "鸢尾暮色",
    "light": [
      "#7958c8",
      "#b34379",
      "#22778a"
    ],
    "dark": [
      "#b7a5ff",
      "#f3a6ce",
      "#79d1de"
    ]
  },
  {
    "id": "deepsea",
    "name": "深海鎏金",
    "light": [
      "#1d6f8b",
      "#b4892f",
      "#4c5d8a"
    ],
    "dark": [
      "#7fd2e8",
      "#ecd08a",
      "#a9b6e0"
    ]
  },
  {
    "id": "coast",
    "name": "海盐日落",
    "light": [
      "#14869a",
      "#b64d38",
      "#866519"
    ],
    "dark": [
      "#79d5e5",
      "#ffaf98",
      "#edcf86"
    ]
  },
  {
    "id": "lava",
    "name": "暮色熔岩",
    "light": [
      "#b4465e",
      "#7a4c93",
      "#d97a3d"
    ],
    "dark": [
      "#f2a5b2",
      "#c3a6ea",
      "#f6c39a"
    ]
  },
  {
    "id": "macaron",
    "name": "马卡龙",
    "light": [
      "#329383",
      "#9461ac",
      "#b35a70"
    ],
    "dark": [
      "#a7dfd0",
      "#dab6ef",
      "#f4bacb"
    ]
  },
  {
    "id": "cedar",
    "name": "薄荷雪松",
    "light": [
      "#2e8b74",
      "#8fa06a",
      "#c9a227"
    ],
    "dark": [
      "#9fe0c9",
      "#cfd9a8",
      "#ecd08a"
    ]
  },
  {
    "id": "peach",
    "name": "蜜桃乌龙",
    "light": [
      "#c16648",
      "#7e6541",
      "#6b7d49"
    ],
    "dark": [
      "#f5b79d",
      "#e2cb9d",
      "#c8d7a7"
    ]
  },
  {
    "id": "lavender",
    "name": "蓝调花雾",
    "light": [
      "#467fb2",
      "#7758a6",
      "#9b586e"
    ],
    "dark": [
      "#a5c7e8",
      "#c9b4ef",
      "#e8b4c7"
    ]
  },
  {
    "id": "mist",
    "name": "海雾晨光",
    "light": [
      "#4f7fa8",
      "#8fb9c9",
      "#d9a98a"
    ],
    "dark": [
      "#a9cbe8",
      "#cfe6ec",
      "#f0cfb4"
    ]
  },
  {
    "id": "forest",
    "name": "雨后花园",
    "light": [
      "#3d895f",
      "#8a6532",
      "#625eaa"
    ],
    "dark": [
      "#9bd0af",
      "#dfc392",
      "#bdb8ef"
    ]
  },
  {
    "id": "honey",
    "name": "蜂蜜麦田",
    "light": [
      "#a17a24",
      "#397976",
      "#ad6556"
    ],
    "dark": [
      "#e4c278",
      "#9dcfcb",
      "#e5b0a3"
    ]
  },
  {
    "id": "oasis",
    "name": "沙漠绿洲",
    "light": [
      "#b07a2e",
      "#4e8a6b",
      "#8a5a3c"
    ],
    "dark": [
      "#eccd94",
      "#a8d4b6",
      "#d5ad8c"
    ]
  },
  {
    "id": "ruby",
    "name": "红茶玫瑰",
    "light": [
      "#c04757",
      "#567647",
      "#9b742e"
    ],
    "dark": [
      "#ee9aa5",
      "#b5cda4",
      "#dfc48a"
    ]
  },
  {
    "id": "nightviolet",
    "name": "紫罗兰夜",
    "light": [
      "#6c4ab6",
      "#c05a8e",
      "#2f8fa8"
    ],
    "dark": [
      "#bfa6f5",
      "#f0a8c2",
      "#8fd8e6"
    ]
  }
] as const;
export const corners = [
  {
    "id": "tight",
    "name": "紧致",
    "scale": 0.42
  },
  {
    "id": "default",
    "name": "标准",
    "scale": 1
  },
  {
    "id": "round",
    "name": "圆润",
    "scale": 1.9
  }
] as const;
